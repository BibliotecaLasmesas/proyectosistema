-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 06-02-2017 a las 19:42:53
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `biblioteca`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `bienes`
-- 

CREATE TABLE `bienes` (
  `codigo` varchar(50) collate utf8_spanish_ci NOT NULL,
  `mueble` varchar(50) collate utf8_spanish_ci NOT NULL,
  `descripcion` varchar(50) collate utf8_spanish_ci NOT NULL,
  `fecha` date NOT NULL,
  `sala` varchar(10) collate utf8_spanish_ci NOT NULL,
  `cantidad` int(9) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `bienes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `libros`
-- 

CREATE TABLE `libros` (
  `titulo` varchar(30) collate utf8_spanish_ci NOT NULL,
  `autor` varchar(30) collate utf8_spanish_ci NOT NULL,
  `codigo` varchar(9) collate utf8_spanish_ci NOT NULL,
  `editorial` varchar(9) collate utf8_spanish_ci NOT NULL,
  `anio` date NOT NULL,
  `volumen` int(9) NOT NULL,
  `clasificacion` varchar(9) collate utf8_spanish_ci NOT NULL,
  `cantidad` int(9) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `libros`
-- 

INSERT INTO `libros` VALUES ('matematica', 'pedro', '01', 'los alpes', '1996-03-12', 4, 'General', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `cedula` int(9) NOT NULL,
  `p_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `s_nombre` varchar(100) collate utf8_spanish_ci NOT NULL,
  `p_apellido` varchar(100) collate utf8_spanish_ci NOT NULL,
  `s_apellido` varchar(100) collate utf8_spanish_ci NOT NULL,
  `email` varchar(100) collate utf8_spanish_ci NOT NULL,
  `fn` date NOT NULL,
  `tlfcasa` varchar(100) collate utf8_spanish_ci NOT NULL,
  `celular` varchar(100) collate utf8_spanish_ci NOT NULL,
  `genero` varchar(100) collate utf8_spanish_ci NOT NULL,
  `direccion` varchar(100) collate utf8_spanish_ci NOT NULL,
  UNIQUE KEY `cedula` (`cedula`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

